import { initializeApp } from "https://www.gstatic.com/firebasejs/12.14.0/firebase-app.js";
import { getDatabase, ref, push, set, remove, update, onValue, get } from "https://www.gstatic.com/firebasejs/12.14.0/firebase-database.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.14.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCAq0QNY7tE1td489ZakrVKjTg6iRe5nyc",
  authDomain: "nexus23-7f041.firebaseapp.com",
  databaseURL: "https://nexus23-7f041-default-rtdb.firebaseio.com",
  projectId: "nexus23-7f041",
  storageBucket: "nexus23-7f041.firebasestorage.app",
  messagingSenderId: "231907744812",
  appId: "1:231907744812:web:98be1a8a497abb151ac589",
  measurementId: "G-LDVBX9VQYC"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

const productosRef = ref(db, 'delimani_productos');
const historialRef = ref(db, 'delimani_historial');
const usuariosRef = ref(db, 'usuarios');
const gastosRef = ref(db, 'delimani_gastos');
const pedidosRef = ref(db, 'delimani_pedidos');
const adminTelegramRef = ref(db, 'delimani_admin_telegram');

// --- Notificación por Telegram (a todos los admins que se hayan registrado) ---
const TELEGRAM_BOT_TOKEN = '8679373819:AAH_GkurO0lkyQHddvshXc-knBbGDd-zhrM';
// Chat_id de respaldo, usado solo si ningún admin ha configurado el suyo todavía.
const TELEGRAM_CHAT_ID_RESPALDO = '7533461771';

window.guardarChatIdTelegramPropio = function(uid, chatId) {
  return set(ref(db, 'delimani_admin_telegram/' + uid), chatId);
};

async function obtenerChatIdsAdmin() {
  const snap = await get(adminTelegramRef);
  const data = snap.val() || {};
  const ids = Object.values(data).filter(Boolean);
  if (ids.length === 0 && TELEGRAM_CHAT_ID_RESPALDO) ids.push(TELEGRAM_CHAT_ID_RESPALDO);
  return ids;
}

function enviarMensajeTelegram(chatId, mensaje) {
  fetch('https://api.telegram.org/bot' + TELEGRAM_BOT_TOKEN + '/sendMessage', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text: mensaje })
  }).catch(err => console.error('Error enviando notificación a Telegram:', err));
}

async function notificarTelegram(mensaje) {
  if (!TELEGRAM_BOT_TOKEN) return;
  const ids = await obtenerChatIdsAdmin();
  ids.forEach(id => enviarMensajeTelegram(id, mensaje));
}

async function perfilSiValido(uid) {
  const snap = await get(ref(db, 'usuarios/' + uid));
  const datos = snap.val();
  if (!datos || datos.estado === 'pendiente') return null;
  return { nombre: datos.usuario, negocio: datos.negocio || '', telefono: datos.telefono || '', rol: datos.rol, _key: uid };
}

// --- Auto-registro de clientes (catálogo público) ---
window.registrarClienteFirebase = async function(usuario, negocio, telefono, password) {
  const correoInterno = usuario.toLowerCase().replace(/\s+/g, '') + '@nexus23.local';
  const credencial = await createUserWithEmailAndPassword(auth, correoInterno, password);
  const uid = credencial.user.uid;
  await set(ref(db, 'usuarios/' + uid), { usuario, negocio: negocio || '', telefono: telefono || '', rol: 'cliente', estado: 'aprobado' });
  return { nombre: usuario, negocio: negocio || '', telefono: telefono || '', rol: 'cliente', _key: uid };
};

window.loginConFirebase = async function(usuario, password) {
  const correoInterno = usuario.toLowerCase().replace(/\s+/g, '') + '@nexus23.local';
  try {
    const credencial = await signInWithEmailAndPassword(auth, correoInterno, password);
    const perfil = await perfilSiValido(credencial.user.uid);

    if (!perfil) {
      await signOut(auth);
      return null;
    }

    return perfil;

  } catch (e) {
    console.error('Login error:', e);
    return null;
  }
};

window.cerrarSesionFirebase = function() {
  signOut(auth);
};

window.revisarSesionExistente = function(callback) {
  let primeraRevision = true;
  onAuthStateChanged(auth, async (user) => {
    if (!primeraRevision) return;
    primeraRevision = false;

    if (!user) { callback(null); return; }

    const perfil = await perfilSiValido(user.uid);
    if (!perfil) { await signOut(auth); }
    callback(perfil);
  });
};

window.guardarEnFirebase = (nuevo) => push(productosRef, nuevo);
window.eliminarDeFirebase = (key) => remove(ref(db, 'delimani_productos/' + key));
window.actualizarEnFirebase = (key, cambios) => update(ref(db, 'delimani_productos/' + key), cambios);

onValue(productosRef, (snapshot) => {
  const data = snapshot.val();
  const lista = data ? Object.entries(data).map(([k,v]) => ({...v, _key:k})) : [];
  if (window.actualizarInventarioDesdeFirebase) window.actualizarInventarioDesdeFirebase(lista);
});

window.guardarHistorialEnFirebase = function(entrada) {
  push(historialRef, entrada);
};

window.cargarHistorialDesdeFirebase = function(callback) {
  onValue(historialRef, (snapshot) => {
    const data = snapshot.val();
    const lista = data ? Object.entries(data).map(([k,v]) => ({...v, _key:k})) : [];
    lista.sort((a,b) => new Date(b.fecha) - new Date(a.fecha));
    callback(lista);
  });
};

// --- Gestión de usuarios (misma tabla 'usuarios' que NEXUS23) ---
window.escucharUsuarios = function(callback) {
  onValue(usuariosRef, (snapshot) => {
    callback(snapshot.val() || {});
  });
};

window.actualizarUsuarioFirebase = (uid, cambios) => update(ref(db, 'usuarios/' + uid), cambios);
window.eliminarUsuarioFirebase = (uid) => remove(ref(db, 'usuarios/' + uid));

let appSecundaria = null;
function obtenerAuthSecundaria() {
  if (!appSecundaria) {
    appSecundaria = initializeApp(firebaseConfig, 'AdminCreate');
  }
  return getAuth(appSecundaria);
}

window.crearUsuarioAdminFirebase = async function(usuario, password, rol) {
  const correoInterno = usuario.toLowerCase().replace(/\s+/g, '') + '@nexus23.local';
  const authSecundaria = obtenerAuthSecundaria();
  const credencial = await createUserWithEmailAndPassword(authSecundaria, correoInterno, password);
  const uid = credencial.user.uid;
  await set(ref(db, 'usuarios/' + uid), { usuario, rol, estado: 'aprobado' });
  await signOut(authSecundaria);
  return uid;
};

// --- Costos de inversión (Ganancias) ---
window.escucharGastos = function(callback) {
  onValue(gastosRef, (snapshot) => {
    callback(snapshot.val());
  });
};

window.actualizarGastosFirebase = (cambios) => update(gastosRef, cambios);

window.asegurarGastosSeed = async function(defaults) {
  const snap = await get(gastosRef);
  if (!snap.exists()) {
    await set(gastosRef, defaults);
  }
};

// --- Pedidos del catálogo ---
window.guardarPedidoEnFirebase = function(pedido) {
  push(pedidosRef, pedido);
  let msg = '🥜 Nuevo pedido en Maní García\n' +
    pedido.usuarioNombre + ' pidió ' + pedido.cantidad + ' u. de ' + pedido.productoNombre +
    ' ($' + (pedido.precio * pedido.cantidad).toLocaleString('es-CO') + ')';
  if (pedido.negocio) msg += '\nNegocio: ' + pedido.negocio;
  if (pedido.nota) msg += '\nNota: ' + pedido.nota;
  if (pedido.lat && pedido.lng) msg += '\nUbicación: https://www.google.com/maps?q=' + pedido.lat + ',' + pedido.lng;
  notificarTelegram(msg);
};

window.actualizarPedidoFirebase = (key, cambios) => update(ref(db, 'delimani_pedidos/' + key), cambios);

window.escucharPedidos = function(callback) {
  onValue(pedidosRef, (snapshot) => {
    callback(snapshot.val() || {});
  });
};

window.firebaseReady = true;
